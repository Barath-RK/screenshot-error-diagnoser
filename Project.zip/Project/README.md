# 📸 Screenshot Error Diagnoser

> AI-powered tool that extracts error text from screenshots and provides fix steps using Vision LLM + RAG

## 🎯 Problem Statement
Web UI accepts screenshot upload → Vision LLM extracts error text, RAG-matches to knowledge base, replies with numbered fix steps.

## 🚀 AI Capability Demonstrated
- **Vision LLM** - Extracts error text from images
- **RAG (Retrieval Augmented Generation)** - Matches errors to knowledge base
- **External API Integration** - OpenRouter API for LLM access

## 📋 Requirements

- Python 3.11+
- OpenRouter API Key ([Get free credits](https://openrouter.ai/keys))

## 🔧 Setup Instructions

```bash
# Clone repository
git clone https://github.com/vishnu-psvpec/06-screenshot-error-diagnoser.git
cd 06-screenshot-error-diagnoser

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Create .env file with your API key
echo OPENROUTER_API_KEY=your_key_here > .env

# Run the application
python app.py