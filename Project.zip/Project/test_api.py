import requests

api_key = "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"
headers = {"Authorization": f"Bearer {api_key}"}

response = requests.get("https://openrouter.ai/api/v1/auth/key", headers=headers)
print(f"Status: {response.status_code}")
print(f"Response: {response.text}")