let currentError = null;
let currentFix = null;
let currentCredits = null;

document.addEventListener('DOMContentLoaded', () => {
    loadHistory();
    loadKB();
    loadCredits();
    setupDragDrop();
    setupUpload();
});

function setupDragDrop() {
    const zone = document.getElementById('uploadZone');
    
    zone.addEventListener('dragover', (e) => {
        e.preventDefault();
        zone.classList.add('drag-over');
    });
    
    zone.addEventListener('dragleave', () => {
        zone.classList.remove('drag-over');
    });
    
    zone.addEventListener('drop', (e) => {
        e.preventDefault();
        zone.classList.remove('drag-over');
        const file = e.dataTransfer.files[0];
        if (file && file.type.startsWith('image/')) {
            handleFile(file);
        }
    });
}

function setupUpload() {
    const fileInput = document.getElementById('fileInput');
    const uploadBtn = document.getElementById('uploadBtn');
    
    fileInput.addEventListener('change', (e) => {
        if (e.target.files[0]) handleFile(e.target.files[0]);
    });
    
    uploadBtn.addEventListener('click', () => {
        fileInput.click();
    });
}

function updateLoadingStep(step) {
    const steps = ['step1', 'step2', 'step3'];
    const statusTexts = ['📷 Reading image...', '🔍 Extracting error...', '💡 Generating solution...'];
    
    steps.forEach((s, i) => {
        const el = document.getElementById(s);
        const statusEl = document.getElementById('loadingStatus');
        if (el) {
            if (i + 1 === step) {
                el.classList.add('active');
                if (statusEl) statusEl.textContent = statusTexts[i];
            } else {
                el.classList.remove('active');
            }
        }
    });
}

function handleFile(file) {
    if (file.size > 10 * 1024 * 1024) {
        alert('File too large! Max 10MB');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
        const preview = document.getElementById('previewImage');
        preview.src = e.target.result;
        document.getElementById('previewCard').style.display = 'block';
    };
    reader.readAsDataURL(file);
    
    diagnose(file);
}

function clearPreview() {
    document.getElementById('previewCard').style.display = 'none';
    document.getElementById('results').style.display = 'none';
    document.getElementById('extraFeatures').style.display = 'none';
    document.getElementById('fileInput').value = '';
    document.getElementById('extraContent').classList.remove('show');
}

async function diagnose(file) {
    const loading = document.getElementById('loadingOverlay');
    const results = document.getElementById('results');
    
    loading.style.display = 'flex';
    results.style.display = 'none';
    document.getElementById('extraFeatures').style.display = 'none';
    document.getElementById('extraContent').classList.remove('show');
    
    const formData = new FormData();
    formData.append('image', file);
    
    try {
        updateLoadingStep(1);
        const response = await fetch('/diagnose', { method: 'POST', body: formData });
        
        updateLoadingStep(2);
        const data = await response.json();
        updateLoadingStep(3);
        
        if (response.ok && data.success) {
            setTimeout(() => {
                displayResults(data);
                loading.style.display = 'none';
                results.style.display = 'block';
                document.getElementById('extraFeatures').style.display = 'flex';
                loadHistory();
                loadKB(); // Reload KB to show newly added errors
                if (data.credits) updateCreditsDisplay(data.credits);
            }, 500);
        } else {
            throw new Error(data.error || 'Diagnosis failed');
        }
    } catch (error) {
        loading.style.display = 'none';
        alert('Error: ' + error.message);
    }
}

function displayResults(data) {
    currentError = data.error_text;
    currentFix = data.fix_steps;
    
    document.getElementById('errorMessage').textContent = data.error_text;
    document.getElementById('fixSteps').innerHTML = marked.parse(data.fix_steps);
    
    // Show auto-learn notification if applicable
    if (data.auto_learned) {
        showAutoLearnNotification();
    }
}

function showAutoLearnNotification() {
    const container = document.getElementById('resultMeta');
    if (container) {
        // Remove existing badge
        const existingBadge = container.querySelector('.auto-learn-badge');
        if (existingBadge) existingBadge.remove();
        
        const badge = document.createElement('div');
        badge.className = 'auto-learn-badge';
        badge.innerHTML = '🧠 New error auto-learned & added to Knowledge Base';
        container.appendChild(badge);
        
        // Update auto-learned count
        updateAutoLearnedCount();
        
        setTimeout(() => badge.remove(), 5000);
    }
}

async function updateAutoLearnedCount() {
    try {
        const response = await fetch('/api/kb');
        const kb = await response.json();
        const autoLearned = kb.filter(item => item.added_at).length;
        const autoLearnedEl = document.getElementById('autoLearnedCount');
        if (autoLearnedEl) autoLearnedEl.textContent = autoLearned;
    } catch (error) {
        console.error('Failed to update auto-learned count:', error);
    }
}

function copySolution() {
    const text = `🔴 ERROR DETECTED:\n${currentError}\n\n🔧 FIX STEPS:\n${currentFix}\n\n---\nDiagnosed by Screenshot Error Diagnoser | AI-Powered`;
    navigator.clipboard.writeText(text);
    
    // Show temporary feedback
    const btn = event.target;
    const originalText = btn.textContent;
    btn.textContent = '✓ Copied!';
    setTimeout(() => {
        btn.textContent = originalText;
    }, 2000);
}

function newDiagnosis() {
    clearPreview();
    document.getElementById('fileInput').click();
}

function toggleKB() {
    const panel = document.getElementById('kbPanel');
    if (panel.style.display === 'none') {
        panel.style.display = 'block';
        loadKB();
    } else {
        panel.style.display = 'none';
    }
}

async function explainError() {
    if (!currentError) return;
    
    const content = document.getElementById('extraContent');
    content.innerHTML = '<div class="empty-state">🤔 Generating simple explanation...</div>';
    content.classList.add('show');
    
    try {
        const response = await fetch('/api/explain', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: currentError })
        });
        
        const data = await response.json();
        if (data.explanation) {
            content.innerHTML = marked.parse(data.explanation);
            if (data.credits) updateCreditsDisplay(data.credits);
        } else {
            content.innerHTML = '<p>❌ Could not generate explanation. Please try again.</p>';
        }
    } catch (error) {
        content.innerHTML = '<p>❌ Could not generate explanation. Please try again.</p>';
    }
}

async function findSimilar() {
    if (!currentError) return;
    
    const content = document.getElementById('extraContent');
    content.innerHTML = '<div class="empty-state">🔍 Searching knowledge base...</div>';
    content.classList.add('show');
    
    try {
        const response = await fetch('/api/similar-errors', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: currentError })
        });
        
        const data = await response.json();
        
        if (data.similar_errors && data.similar_errors.length > 0) {
            let html = '<h4>📚 Similar errors in knowledge base:</h4><ul>';
            data.similar_errors.forEach(err => {
                html += `<li><strong>⚠️ ${escapeHtml(err.error)}</strong><br><small>🔧 ${escapeHtml(err.fix.substring(0, 100))}${err.fix.length > 100 ? '...' : ''}</small></li>`;
            });
            html += '</ul>';
            content.innerHTML = html;
        } else {
            content.innerHTML = '<p>📭 No similar errors found in knowledge base.</p>';
        }
    } catch (error) {
        content.innerHTML = '<p>❌ Could not find similar errors.</p>';
    }
}

async function loadHistory() {
    try {
        const response = await fetch('/api/history');
        const history = await response.json();
        const container = document.getElementById('historyList');
        
        if (!history || history.length === 0) {
            container.innerHTML = '<div class="empty-state">📭 No diagnoses yet. Upload a screenshot to get started!</div>';
            return;
        }
        
        container.innerHTML = history.map(item => `
            <div class="history-item">
                <div class="history-error">⚠️ ${escapeHtml(item.error_text.substring(0, 80))}${item.error_text.length > 80 ? '...' : ''}</div>
                <div class="history-time">📅 ${new Date(item.timestamp).toLocaleString()}</div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load history:', error);
    }
}

async function loadKB() {
    try {
        const response = await fetch('/api/kb');
        const kb = await response.json();
        const container = document.getElementById('kbList');
        const stats = document.getElementById('kbStats');
        const badge = document.getElementById('kbCountBadge');
        
        if (!kb || kb.length === 0) {
            container.innerHTML = '<div class="empty-state">📭 No entries yet. Upload an error to auto-learn!</div>';
            if (stats) stats.textContent = '0 entries';
            if (badge) badge.textContent = '0';
            return;
        }
        
        if (stats) stats.textContent = `${kb.length} entries`;
        if (badge) badge.textContent = kb.length;
        
        container.innerHTML = kb.map((item, index) => `
            <div class="kb-item">
                <div style="flex: 1;">
                    <strong>⚠️ ${escapeHtml(item.error)}</strong>
                    <div class="kb-fix">🔧 ${escapeHtml(item.fix.substring(0, 120))}${item.fix.length > 120 ? '...' : ''}</div>
                    ${item.count ? `<span class="kb-count-badge">Occurrences: ${item.count}</span>` : ''}
                </div>
                <button class="delete-kb-btn" onclick="deleteKB(${index})">Delete</button>
            </div>
        `).join('');
        
        // Update auto-learned count
        const autoLearned = kb.filter(item => item.added_at).length;
        const autoLearnedEl = document.getElementById('autoLearnedCount');
        if (autoLearnedEl) autoLearnedEl.textContent = autoLearned;
        
    } catch (error) {
        console.error('Failed to load KB:', error);
    }
}

async function addToKB() {
    const error = document.getElementById('newError').value.trim();
    const fix = document.getElementById('newFix').value.trim();
    
    if (!error || !fix) {
        alert('Please fill both fields');
        return;
    }
    
    try {
        const response = await fetch('/api/kb', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error, fix })
        });
        
        if (response.ok) {
            document.getElementById('newError').value = '';
            document.getElementById('newFix').value = '';
            loadKB();
            alert('✓ Added to knowledge base!');
        } else {
            alert('Failed to add to KB');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
}

async function deleteKB(index) {
    if (!confirm('Delete this knowledge base entry?')) return;
    
    try {
        const response = await fetch(`/api/kb/${index}`, { method: 'DELETE' });
        if (response.ok) {
            loadKB();
        } else {
            alert('Failed to delete');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
}

async function loadCredits() {
    try {
        const response = await fetch('/api/credits');
        const credits = await response.json();
        updateCreditsDisplay(credits);
    } catch (error) {
        console.error('Failed to load credits:', error);
    }
}

function updateCreditsDisplay(credits) {
    if (!credits) return;
    
    const totalTokens = document.getElementById('totalTokens');
    const dailyTokens = document.getElementById('dailyTokens');
    const totalDiagnoses = document.getElementById('totalDiagnoses');
    const creditAmount = document.getElementById('creditAmount');
    
    if (totalTokens) totalTokens.textContent = credits.total_tokens || 0;
    if (dailyTokens) dailyTokens.textContent = credits.daily_tokens || 0;
    if (totalDiagnoses) totalDiagnoses.textContent = credits.total_diagnoses || 0;
    if (creditAmount) {
        const cost = (credits.estimated_cost || 0).toFixed(6);
        creditAmount.textContent = `$${cost}`;
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, (m) => {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}