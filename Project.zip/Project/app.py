"""
Screenshot Error Diagnoser - Complete Working Version
Features: Auto-Learn | Credits Tracking | Knowledge Base | Fast Response
"""
import os
import json
import base64
from pathlib import Path
from datetime import datetime
import requests
from flask import Flask, request, jsonify, render_template, send_from_directory
from dotenv import load_dotenv

# Load .env file
env_path = Path(__file__).parent / '.env'
load_dotenv(dotenv_path=env_path)

app = Flask(__name__, static_folder='static', template_folder='templates')

KB_PATH = Path("knowledge_base.json")
HISTORY_PATH = Path("diagnosis_history.json")
CREDITS_PATH = Path("credits_usage.json")

def load_kb() -> list:
    """Load knowledge base from JSON file."""
    if KB_PATH.exists():
        try:
            with open(KB_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception:
            pass
    # Default knowledge base
    defaults = [
        {"error": "ModuleNotFoundError", "fix": "Run: pip install <module_name>", "count": 5},
        {"error": "ECONNREFUSED", "fix": "Start the service: npm start or docker-compose up", "count": 3},
        {"error": "CORS policy", "fix": "Add CORS headers or use a proxy", "count": 4},
        {"error": "404 Not Found", "fix": "Check URL path and HTTP method", "count": 6},
        {"error": "Permission denied", "fix": "Run: chmod +x <file> or use sudo", "count": 3},
        {"error": "Port already in use", "fix": "Find process: lsof -i :<port>, then kill it", "count": 4},
        {"error": "Out of Memory", "fix": "Increase memory limit. For Node: --max-old-space-size=4096", "count": 2},
    ]
    save_kb(defaults)
    return defaults

def save_kb(kb_data: list):
    """Save knowledge base to file."""
    with open(KB_PATH, "w", encoding="utf-8") as f:
        json.dump(kb_data, f, indent=4)

def auto_add_to_kb(error_text: str, fix_steps: str):
    """Automatically add new error to knowledge base."""
    kb = load_kb()
    error_lower = error_text.lower()
    
    # Check if error already exists
    for entry in kb:
        if entry.get("error", "").lower() in error_lower or error_lower in entry.get("error", "").lower():
            # Increment occurrence count
            entry["count"] = entry.get("count", 0) + 1
            save_kb(kb)
            return False
    
    # Add new error
    new_entry = {
        "error": error_text[:100],
        "fix": fix_steps[:200] + ("..." if len(fix_steps) > 200 else ""),
        "count": 1,
        "added_at": datetime.now().isoformat()
    }
    kb.append(new_entry)
    save_kb(kb)
    print(f"📚 Auto-learned: {error_text[:50]}...")
    return True

def save_to_history(entry: dict):
    """Save diagnosis to history."""
    history = []
    if HISTORY_PATH.exists():
        try:
            with open(HISTORY_PATH, "r", encoding="utf-8") as f:
                history = json.load(f)
        except Exception:
            pass
    entry["timestamp"] = datetime.now().isoformat()
    history.insert(0, entry)
    history = history[:20]
    with open(HISTORY_PATH, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=4)

def update_credits():
    """Update credits usage."""
    credits = {"total_tokens": 0, "daily_tokens": 0, "total_diagnoses": 0, "estimated_cost": 0.0}
    if CREDITS_PATH.exists():
        try:
            with open(CREDITS_PATH, "r", encoding="utf-8") as f:
                credits = json.load(f)
        except Exception:
            pass
    
    # Add tokens for this diagnosis (approx 350 tokens per diagnosis)
    credits["total_tokens"] = credits.get("total_tokens", 0) + 350
    credits["daily_tokens"] = credits.get("daily_tokens", 0) + 350
    credits["total_diagnoses"] = credits.get("total_diagnoses", 0) + 1
    credits["estimated_cost"] = round((credits["total_tokens"] / 1000) * 0.001, 6)
    
    with open(CREDITS_PATH, "w", encoding="utf-8") as f:
        json.dump(credits, f, indent=4)
    return credits

def get_credits_stats() -> dict:
    """Get current credits statistics."""
    if CREDITS_PATH.exists():
        try:
            with open(CREDITS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                return {
                    "total_tokens": data.get("total_tokens", 0),
                    "daily_tokens": data.get("daily_tokens", 0),
                    "total_diagnoses": data.get("total_diagnoses", 0),
                    "estimated_cost": data.get("estimated_cost", 0.0),
                }
        except Exception:
            pass
    return {"total_tokens": 0, "daily_tokens": 0, "total_diagnoses": 0, "estimated_cost": 0.0}

def rag_lookup(error_text: str) -> list:
    """Keyword-based RAG matching."""
    kb = load_kb()
    matches = []
    error_lower = error_text.lower()
    for entry in kb:
        if isinstance(entry, dict) and entry.get("error", "").lower() in error_lower:
            matches.append(entry)
    # Sort by frequency (most common first)
    matches.sort(key=lambda x: x.get("count", 0), reverse=True)
    return matches[:3]

def call_openrouter(messages, max_tokens=500):
    """Call OpenRouter with working free models"""
    api_key = os.environ.get("OPENROUTER_API_KEY")
    
    if not api_key:
        raise Exception("OpenRouter API Key not configured.")
    
    # Use openrouter/free - auto-router that picks best available free model
    model = "openrouter/free"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://github.com/vishnu-psvpec/06-screenshot-error-diagnoser",
        "X-Title": "Screenshot Error Diagnoser"
    }
    
    payload = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": 0.7
    }
    
    try:
        print(f"🔄 Calling OpenRouter...")
        resp = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers=headers,
            json=payload,
            timeout=60
        )
        
        print(f"📡 Response status: {resp.status_code}")
        
        if resp.status_code == 200:
            result = resp.json()
            content = result["choices"][0].get("message", {}).get("content", "")
            if content:
                return content.strip()
            else:
                raise Exception("Empty response from model")
        else:
            error_detail = resp.json() if resp.text else {"error": f"HTTP {resp.status_code}"}
            error_msg = error_detail.get('error', {}).get('message', str(error_detail))
            raise Exception(f"API Error ({resp.status_code}): {error_msg}")
                
    except requests.exceptions.Timeout:
        raise Exception("Request timed out. Please try again.")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error: {str(e)}")
    except Exception as e:
        raise Exception(f"API call failed: {str(e)}")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/static/<path:filename>")
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route("/api/kb", methods=["GET"])
def get_kb():
    return jsonify(load_kb())

@app.route("/api/kb", methods=["POST"])
def add_kb():
    data = request.json
    if not data or "error" not in data or "fix" not in data:
        return jsonify({"error": "Invalid data"}), 400
    
    kb = load_kb()
    kb.append({
        "error": data["error"].strip(),
        "fix": data["fix"].strip(),
        "count": 1,
        "added_at": datetime.now().isoformat()
    })
    save_kb(kb)
    return jsonify({"status": "success", "count": len(kb)})

@app.route("/api/kb/<int:idx>", methods=["DELETE"])
def delete_kb(idx):
    kb = load_kb()
    if 0 <= idx < len(kb):
        kb.pop(idx)
        save_kb(kb)
        return jsonify({"status": "success"})
    return jsonify({"error": "Not found"}), 404

@app.route("/api/history", methods=["GET"])
def get_history():
    if HISTORY_PATH.exists():
        try:
            with open(HISTORY_PATH, "r", encoding="utf-8") as f:
                history = json.load(f)
                return jsonify(history if isinstance(history, list) else [])
        except Exception:
            return jsonify([])
    return jsonify([])

@app.route("/api/credits", methods=["GET"])
def get_credits():
    return jsonify(get_credits_stats())

@app.route("/api/explain", methods=["POST"])
def explain_error():
    data = request.json
    error_text = data.get("error", "")
    
    if not error_text:
        return jsonify({"error": "No error text provided"}), 400
    
    try:
        messages = [{"role": "user", "content": f"Explain this error in very simple terms (like to a beginner): {error_text}"}]
        explanation = call_openrouter(messages, max_tokens=300)
        return jsonify({"explanation": explanation})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/similar-errors", methods=["POST"])
def get_similar_errors():
    data = request.json
    error_text = data.get("error", "")
    
    if not error_text:
        return jsonify({"error": "No error text provided"}), 400
    
    kb = load_kb()
    similar = []
    error_lower = error_text.lower()
    error_words = set(error_lower.split())
    
    for entry in kb:
        if isinstance(entry, dict):
            entry_lower = entry.get("error", "").lower()
            if any(word in entry_lower for word in error_words):
                similar.append(entry)
    
    return jsonify({"similar_errors": similar[:5]})

@app.route("/diagnose", methods=["POST"])
def diagnose():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    img = request.files["image"]
    
    # Validate file
    img.seek(0, 2)
    file_size = img.tell()
    img.seek(0)
    
    if file_size > 10 * 1024 * 1024:
        return jsonify({"error": "File too large. Max 10MB"}), 400
    
    if not img.content_type or not img.content_type.startswith('image/'):
        return jsonify({"error": "Invalid file type. Please upload an image."}), 400
    
    img_data = base64.b64encode(img.read()).decode()
    media_type = img.content_type

    try:
        # Step 1: Extract error using Vision LLM
        ocr_messages = [{
            "role": "user",
            "content": [
                {"type": "text", "text": "Extract the exact error message from this screenshot. Return ONLY the error text, nothing else. If no error, return 'NO_ERROR'."},
                {"type": "image_url", "image_url": {"url": f"data:{media_type};base64,{img_data}"}}
            ]
        }]
        
        print("🔍 Extracting error from screenshot...")
        error_text = call_openrouter(ocr_messages, max_tokens=200)
        error_text = error_text.strip()
        print(f"📝 Extracted error: {error_text[:100]}...")
        
        if not error_text or error_text == "NO_ERROR" or len(error_text) < 5:
            return jsonify({
                "success": True,
                "error_text": "⚠️ No error could be detected",
                "fix_steps": "**Tips for better results:**\n\n1. Take a clearer screenshot\n2. Zoom in on the error text\n3. Ensure good lighting\n4. Avoid screen glare",
                "kb_matches": 0,
                "auto_learned": False
            })

        # Step 2: RAG lookup
        kb_matches = rag_lookup(error_text)
        
        # Step 3: Generate fix steps
        if kb_matches:
            kb_context = "\n".join([f"- {m['error']}: {m['fix']}" for m in kb_matches])
            fix_prompt = f"""Error: {error_text}

Known fixes from knowledge base:
{kb_context}

Provide 3-5 numbered fix steps. Be specific and actionable."""
        else:
            fix_prompt = f"""Error: {error_text}

Provide 3-5 numbered fix steps for this error. Include common solutions and commands where relevant."""

        fix_messages = [{"role": "user", "content": fix_prompt}]
        print("💡 Generating fix steps...")
        fix_steps = call_openrouter(fix_messages, max_tokens=600)

        # Auto-learn to knowledge base
        is_new = auto_add_to_kb(error_text, fix_steps)
        
        # Update credits
        credits = update_credits()

        # Save to history
        save_to_history({
            "error_text": error_text[:150],
            "fix_steps": fix_steps[:300],
            "kb_matches": len(kb_matches)
        })

        return jsonify({
            "success": True,
            "error_text": error_text,
            "fix_steps": fix_steps,
            "kb_matches": len(kb_matches),
            "auto_learned": is_new,
            "credits": credits
        })

    except Exception as e:
        error_msg = str(e)
        print(f"❌ Error: {error_msg}")
        return jsonify({
            "success": False, 
            "error": error_msg,
            "error_text": "⚠️ API Error",
            "fix_steps": f"**Error Details:** {error_msg}\n\n**Possible fixes:**\n1. Check your internet connection\n2. Verify your API key is valid\n3. Try again in a few seconds",
            "auto_learned": False
        }), 500

if __name__ == "__main__":
    print("=" * 55)
    print("📸 Screenshot Error Diagnoser")
    print("=" * 55)
    print(f"📍 URL: http://localhost:5001")
    print(f"🤖 Using: openrouter/free (auto-router)")
    print(f"⚡ Features: Auto-Learn | Credits Tracking | RAG Knowledge Base")
    
    # Initialize credits file if not exists
    if not CREDITS_PATH.exists():
        initial_credits = {
            "total_tokens": 0,
            "daily_tokens": 0,
            "total_diagnoses": 0,
            "estimated_cost": 0.0,
            "last_reset": datetime.now().date().isoformat(),
        }
        with open(CREDITS_PATH, "w", encoding="utf-8") as f:
            json.dump(initial_credits, f, indent=4)
        print("✅ Credits tracking initialized")
    
    api_key = os.environ.get("OPENROUTER_API_KEY")
    if api_key:
        print(f"✅ API Key loaded: {api_key[:20]}...")
        print("✅ Auto-learning ENABLED - New errors will be added to KB automatically")
    else:
        print(f"❌ API Key NOT found! Creating .env file...")
        with open(".env", "w") as f:
            f.write("OPENROUTER_API_KEY=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")
        print("✅ Created .env file with your API key")
    
    print("=" * 55)
    app.run(debug=True, port=5001, threaded=True)